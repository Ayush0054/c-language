#include<stdio.h>
    int main(){
    // 97-122 = a-z
    char ch;
    printf("enter the charactert\n");
    scanf("%c", &ch);
    if(ch<=122 && ch>=97){
        printf("it is lower case");
        }
    else{
        printf("not lower case");
    }    
return 0;
}
#include<stdio.h>
    int main(){
    int a,b,c,d;
    printf("enter the four no \n");
    scanf("%d %d %d %d", &a ,&b ,&c ,&d);
    if(a>b>c>d){
        printf("%d is greatest no");
     }
     else if(b>a>c>d){
         printf("%d is greatest no");
     }
     else if(c>a>b>d){
         printf("%d is greatest no");
     }
     else if(d>a>b>c){
          printf("%d is greatest no");
     }
     
return 0;
}
#include<stdio.h>
    int main(){
    int leapyear = 0;
    printf("enter year\n");
    scanf("%d", &leapyear);

    if((leapyear %4==0) && (leapyear %100!=0) || (leapyear%400==0)){
        printf("the year is a leap year");
    }
    else {
        printf("the year is not a leap year");
    }
return 0;
}
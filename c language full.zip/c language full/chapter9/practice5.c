#include<stdio.h>
struct account{
    int accountno;
    int date; //ddmmyyyy
    float balance;
};
    int main(){
        struct account customer[100];
        customer[0].accountno = 619327;
        customer[0].date = 15032003;
        customer[0].balance =34232;
printf("acount no %d\n date of opening account is %d\n account balance is %f\n namee of the aacount owner is harry " ,customer[0].accountno 
, customer[0].date,customer[0].balance  );
    
return 0;
}
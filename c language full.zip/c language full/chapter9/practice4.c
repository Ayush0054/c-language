#include<stdio.h>

 typedef struct complexno {
     int real;
     int img;
 } comp;

void display(comp c){
    printf("the real value is %d\n", c.real);
    printf("the imaginary value is %d\n", c.img);

}  
    int main(){
    comp cnums[5];
    for(int i =0;i<5;i++){
        printf("enter the real value for %d num\n", i+1);
        scanf("%d" , &cnums[i].real);
        printf("enter the imagininary value for %d num\n", i+1);
        scanf("%d" , &cnums[i].img);
    }
    for(int i =0;i<5;i++){
        display(cnums[i]);
    }
return 0;
}
#include<stdio.h>
#include<string.h>
struct employee{
    int code;
    float salary;
    char name[10];
};
    int main(){
    struct employee facebook[100];
    facebook[0].code = 100;
    facebook[0].salary = 100.4;
    strcpy(facebook[0].name , "harry");

        facebook[1].code = 120;
    facebook[1].salary = 109.4;
    strcpy(facebook[1].name , "ashan");

        facebook[2].code = 110;
    facebook[2].salary = 108.4;
    strcpy(facebook[2].name , "haanji");
   printf("done");
return 0;
}
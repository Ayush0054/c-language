#include<stdio.h>

typedef struct datetime{
    int day;
    int month;
    int year;
    int hour;
    int minutes;
    int second ;
    
}date;
void display( date d){
    printf("the date is : %d/%d/%d %d:%d:%d utc\n" , d.day , d.month , d.year,d.hour , d.minutes , d.second);
}
int datecmp(date d1 ,date d2){
    // make decision on the basis of year coparison
    if(d1.year > d2.year){
        return 1;
    }
    if(d1.year < d2.year){
        return -1;
    }
    //// make decision on the basis of month coparison
    if(d1.month > d2.month){
        return 1;
    }        
    if(d1.month < d2.month){
        return -1;
    } 
    // make decision on the basis of day coparison  
    if(d1.day > d2.day){
        return 1;
    }        
    if(d1.day < d2.day){
        return -1;
    }
    if(d1.hour > d2.hour){
        return 1;
    }        
    if(d1.hour < d2.hour){
        return -1;
    }        
    if(d1.minutes > d2.minutes){
        return 1;
    }        
    if(d1.minutes < d2.minutes){
        return -1;
    }
    if(d1.second > d2.second){
        return 1;
    }        
    if(d1.second< d2.second){
        return -1;
    }        
    return 0; 
}

    int main(){
    date d1 = {5,4,22,18 , 50,53};
    date d2 = {5,4,22, 17 ,54,43};
    display(d1);
    display(d2);
    int a = datecmp(d1,d2);
    printf("date comparison function returns : %d" , a);
return 0;
}
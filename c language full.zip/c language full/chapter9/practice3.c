#include<stdio.h>
struct complex{
    float real;
    float img;
};    
    int main(){
    struct complex c1,c2;
    c1.real = 3;
    c2.img = 4;
    printf("the no is 3 +4i ,real part is %f and img part is %f\n", c1.real ,c2.img);
return 0;
}
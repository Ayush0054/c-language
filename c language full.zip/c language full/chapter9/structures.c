#include<stdio.h>
#include<string.h>
struct employee{
    int code;
    float salary;
    char name[10];
};
    int main(){
    // int a =34;
    // char b ='g';
    // float d =435.3;
  struct employee e1;
  e1.code = 100;
  e1.salary = 34.545;
  strcpy(e1.name , "harry");
  printf("%d\n" , e1.code);
  printf("%.3f\n" , e1.salary); //.3f to store decimal till point3
  printf("%s\n" , e1.name);
return 0;
}
#include<stdio.h>
    int main(){
    FILE *ptr1;
    FILE *ptr2;
    int num;
    ptr1 = fopen("a.txt" , "r");
    ptr2 = fopen("b.txt", "w");
   fscanf(ptr1,"%d" ,&num);
    fprintf(ptr2,"%d",num*2);

return 0;
}


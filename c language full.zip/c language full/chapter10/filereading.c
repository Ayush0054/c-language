#include<stdio.h>
    int main(){
    FILE *ptr;
    int num;
    int num2;
    ptr = fopen("harry.txt" , "r");
    fscanf(ptr,"%d" ,&num);
    printf("the value of num is %d\n", num);
    fscanf(ptr,"%d" ,&num2);
    printf("the value of num2 is %d\n", num2);    
return 0;
}
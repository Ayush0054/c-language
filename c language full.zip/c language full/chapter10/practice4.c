#include<stdio.h>
    int main(){
    FILE *ptr;
     char name[10];
     int salary ;
    ptr = fopen("account.txt", "w");
    printf("enter the name of owner\n");
    scanf("%s" , &name);
    printf("enter the salary\n");
    scanf("%d" , &salary);

    
    fprintf(ptr,"%s, %d", name, salary );
    
    fclose(ptr);
   printf("go and see account.txt file");
}
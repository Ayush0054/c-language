#include<stdio.h>
float average(int a, int b, int c);
    
int main(){
    int a,b,c;
    printf("enter the vALUE OF a\n");
    scanf("%d", &a);
     printf("enter the vALUE OF b\n");
    scanf("%d", &b);
     printf("enter the vALUE OF c\n");
    scanf("%d", &c);
    printf("the value of average is %f", average(a,b,c));
return 0;
}
float average(int a, int b ,int c ){
    float result;
    result=(float)(a+b+c)/3;
    return result  ;
}
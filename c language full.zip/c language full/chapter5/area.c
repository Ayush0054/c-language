#include<stdio.h>
#include<math.h>
    int main(){
    int side;
    printf("enter the value of side\n");
    scanf("%d", &side);
    printf("the value of area is %f", pow(side,2));
return 0;
}
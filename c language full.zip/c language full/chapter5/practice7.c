#include<stdio.h>
int natural(int n);
    int main(){
        int n;
        printf("enter n\n");
        scanf("%d" , &n);
        printf("the sum of first  n number is %d is %d", n, natural(n));
    
return 0;
}
int natural(int n){
    if (n==1 ){
        return 1;
    }
    else{
        return (n *(n+1))/2;
    }
}
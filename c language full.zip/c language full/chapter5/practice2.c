#include<stdio.h>
float converter(int c);
    int main(){
        int c;
        printf("enter value of celsius\n");
        scanf("%d", &c);
        printf("celsuis to fahrenhiet is %f",converter(c));
    
return 0;
}
float converter(int c){
    float fahrenhiet;
    fahrenhiet = ((c*9/5) + 32);
    return fahrenhiet;
}
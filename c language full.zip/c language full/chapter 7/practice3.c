#include<stdio.h>
    int main(){
    int mul[10];
    int x;
    printf("enter no whose table to be print \n", x );
    scanf("%d",&x);
    for(int i=0;i<10; i++){
        mul[i] =x*(i+1);
    }
     for(int i=0;i<10; i++){
        printf("%dX%d = %d\n" , x,i+1,mul[i]);
    }
return 0;
}
#include<stdio.h>
void printtable(int *multable, int num , int n ,int level){
    printf("the multiplicaion table of %d is :\n",num);
    for(int i=0;i<10; i++){
        multable[i] = num*(i+1);
    }
    for(int i=0;i<10; i++){
        printf("%dX%d = %d\n" , i+1,multable[i]);
    }


}
    int main(){
    int multable[3][10];
    printtable(multable[0] , 2 , 10 ,0);
    printtable(multable[1] , 7 , 10 ,0);
    printtable(multable[2] , 9 , 10 ,0);
return 0;
}
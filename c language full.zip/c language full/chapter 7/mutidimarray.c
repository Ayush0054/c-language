#include<stdio.h>
    int main(){
    int nstudents = 2;
    int nsubjects =2;
    int marks[2][2];
    for(int i=0;i<nstudents;i++){
        for(int j=0;j<nsubjects;j++){
            printf("enter the marks of student %d in subject %d\n", i+1, j+1);
            scanf("%d" , &marks[i][j]);

        }
    }

    for(int i=0;i<nstudents;i++){
        for(int j=0;j<nsubjects;j++){
            printf(" the marks of student %d in subject %d is: %d\n", i+1, j+1, marks[i][j]);
           
        }
    }
return 0;
}
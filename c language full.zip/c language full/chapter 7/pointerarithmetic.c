#include<stdio.h>
    int main(){
    int i = 34;
    int *j = &i;
    int *k = &j;
    printf("the address of i / the value of j is %u\n" , j);
    //j++;
    j = j +4;
    printf("the address of i /the value of j  is %u\n" , j);
return 0;
}


// #include<stdio.h>
//     int main(){
//     char c = 34;
//     char *j = &c;
//     printf("the address of i / the value of j is %u\n" , j);
//     //j++;
//     j = j +1;
//     printf("the address of i /the value of j  is %u\n" , j);
// return 0;
// }
// #include<stdio.h>
//     int main(){
//     int a[]= {34,454,56};
//     printf("the value of a[0] is %d\n" ,  a[0]);
//     printf("the value of a[1] is %d\n" ,  a[1]);
//     printf("the value of a[2] is %d\n" ,  a[2]);

// return 0;
// }


#include<stdio.h>
    float main(){
    float a[]= {3.4,4.54,5.6};
    printf("the value of a[0] is %f\n" ,  a[0]);
    printf("the value of a[1] is %f\n" ,  a[1]);
    printf("the value of a[2] is %f\n" ,  a[2]);

return 0;
}
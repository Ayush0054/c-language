#include<stdio.h>
void positive(int *integer , int n){
    for(int i=0;i<n; i++){
        if(integer[i]>0){
       printf("the positive no in the array are %d\n" , integer[i]);
        }
    }
}
    int main(){
    int integer[] = {-1,-2,-3,-6,5,4,3,1,6,-7};
    positive(integer , 10);
    
return 0;
}
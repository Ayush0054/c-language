#include<stdio.h>
    int main(){
    int marks[4];
    int *j;
    //j = &marks[0];
    j = &marks;
    for(int i = 0; i<4; i++){
        printf("enter the vslue of %dth student ", i + 1);
        scanf("%d", j);
        j++;
    }
      for(int i = 0; i<4; i++){
        printf(" the vslue of marks for student  %d is %d \n ", i + 1 , marks[i]);

    }
return 0;
}
#include<stdio.h>
    int main(){
     int n;
     printf("enter n\n");
     scanf("%d" , &n);
     for(int i=0; i<11 ;i++){
         printf("n X %d = %d\n", i , n*i);
     }

return 0;
}
#include<stdio.h>
    int main(){
    int i = 5;
    printf("the value after i++ is %d\n", i++);
    printf("the value of i is %d\n", i);
return 0;
}
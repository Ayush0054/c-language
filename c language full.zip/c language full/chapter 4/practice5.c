#include<stdio.h>
    int main(){
    int i;
    while(i=-1){
        if(i<1){
            printf("8");
        }
        else{
            printf("close");
        }
    }
return 0;
}
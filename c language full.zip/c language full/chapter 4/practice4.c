#include<stdio.h>
    int main(){
    int i=0,  factorial=1;
    for(i=1;i<=4;i++){
        factorial *=i;
    }
    printf("the value of factorial is %d",  factorial);
return 0;
}
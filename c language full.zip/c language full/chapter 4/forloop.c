#include<stdio.h>
    int main(){
    for(int a=0; a<10; a++){
        printf("the value of a is %d\n", a);
        }
return 0;
}
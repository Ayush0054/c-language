#include<stdio.h>
    int main(){
        int n;
    printf("enter the value of n\n");
    scanf("%d" , &n);
    for(int i=10; i>0 ; i--){
        printf("the number is %d\n", i);
    }

return 0;
}
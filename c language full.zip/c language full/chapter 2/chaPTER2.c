#include<stdio.h>
    int main(){
    // int a = 4; //type declaration instruct
    // int a = 4, b , c;
    // b = c = a;
    // printf("the value of a is  %d\n", a);
    // printf("the value of b is  %d\n", b);
    // printf("the value of c is  %d\n", c);


    float a = 1.1;
    float b = a + 8.9;
    printf("the value of b is  %f\n", b);
return 0;
}
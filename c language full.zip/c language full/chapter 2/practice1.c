#include<stdio.h>
     int main(){
    // float d = (3.0/8-2);
    // printf("%f",d);



    // int num;
    // printf("enter the no \n");
    // scanf("%d", &num);
    // printf(" divisibility test returns: %d\n", num%97);


    int x = 2, y = 3, z = 3, k = 1;
    int result = 3 * x / y - z + k;
    printf(" the value of result is %d", result);
return 0;
}
#include<stdio.h>
    int main(){
    int x = 2;
    int y = 3;
    printf("the value of 8*y / 3*x  is %d\n", 8*y / 3*x);
return 0;
}
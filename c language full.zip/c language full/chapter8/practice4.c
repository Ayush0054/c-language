#include<stdio.h>
void strcpy(char*source, char *target){
    int i;
for( i=0;source[i] !='\0';i++){
    target[i]= source[i];
}
    target[i]='\0';

}
    int main(){
    char source[]= "harry";
    char target[30];
    strcpy(source, target);
    printf("source was %s\n", source);
    printf("target was %s\n", target);
return 0;
}
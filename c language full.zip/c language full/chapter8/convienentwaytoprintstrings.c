#include<stdio.h>
    int main(){
    // int a=4;
    // printf("%d" , a);
    //char *ptr = "harry bhai" ;
    char ptr[] = "harry bhai" ;
    printf("%s" , ptr);
return 0;
}
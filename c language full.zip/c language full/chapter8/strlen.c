#include<stdio.h>
#include<string.h>
    int main(){
    char *st = "harry";
    int a = strlen(st);
    printf("the length of string st is %d " , a);
return 0;
}
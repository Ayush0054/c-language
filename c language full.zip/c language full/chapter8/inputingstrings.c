#include<stdio.h>
    int main(){
    char s[34];
    printf("enter yor name:");
    scanf("%s" , s);
    printf("your name is %s" , s);
return 0;
}
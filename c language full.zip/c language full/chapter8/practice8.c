#include<stdio.h>
int occurance(char st[],char c){
     char *ptr = st;
     while(*ptr !='\0'){
         if(*ptr==c){
            printf("it is present \n");
         }
         else{
             printf("it is not present \n");
         }
         ptr++;
     }
     
}


    int main(){
    char st[] = "harry";
    int count = occurance(st, 'x');
return 0;
}
#include<stdio.h>
    int main(){
    char str[]= "harry";  //{'h','a' , 'r', 'r' , 'y ' , '\0'};
   
return 0;
}
#include<stdio.h>
    int main(){
    char *ptr = "harry bhai" ;
    //char ptr[] = "harry bhai" ;
    ptr = "subham bhai";
    printf("%s" , ptr);
return 0;
}
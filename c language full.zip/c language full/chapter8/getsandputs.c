#include<stdio.h>
    int main(){
    char s[34];
    printf("enter yor name:");
    gets( s);
    puts(s);
    printf("your name is %s" , s);
return 0;
}
#include<stdio.h>

int main(){
   int i= 345;
   int *j;
   int **jj;

   j = &i;
   jj = &j;
   printf("the value of i is %d" , **jj);  
return 0;
}
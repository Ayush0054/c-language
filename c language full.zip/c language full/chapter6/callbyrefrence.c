#include<stdio.h>
void wrongswap(int a, int b);
void swap(int *a, int *b);
    int main(){
    int x= 3, y= 4;
    printf("the value of x and y before swap  is %d and %d\n", x,y);
   //wrongswap(x,y); // will not work due to calll by value
   swap(&x, &y); // will work due to work by refrence
    printf("the value of x and y after swap is %d and %d\n", x,y);
return 0;
}
void wrongswap(int a, int b){
    int temp;
    temp = a;
    a = b;
    b = temp;

}
void swap(int *a, int *b){
int temp;
    temp = *a;
    *a = *b;
    *b = temp;

}
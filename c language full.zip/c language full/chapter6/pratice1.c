#include<stdio.h>
    int main(){
    int a = 6;
    int *b;
    b = &a;
    printf("the address of variable a is %u\n" , b);
    printf("the value of variable a is %u\n" , *b);
return 0;
}
#include<stdio.h>
void swap(int a, int b);
    int main(){
        int x = 4,  y = 10*x;
     
        printf("the value  of variable x is %u\n" , *(&x));
     swap(&x,&y);
      printf("ten times value of variable x is %u\n" ,*(&x) );
return 0;
}
void swap(int a, int b){
    int temp;
    temp = a;
    a = b;
    b = temp;
}
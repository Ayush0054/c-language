# include<stdio.h>

int main(){
    int _tom;
    printf("hello i am learning c with harry");
    return 0;
}


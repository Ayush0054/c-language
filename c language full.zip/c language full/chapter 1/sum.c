#include <stdio.h>
int main(){
    float a =10.0;
    float b = 12.5;
    printf("the sum of a and b is %f", a + b);
    return 0;
}
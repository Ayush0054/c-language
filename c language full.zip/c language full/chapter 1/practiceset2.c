#include<stdio.h>
int main(){
    int radius = 3;
    float pi = 3.14;
    printf("the area of this circle is %f", pi*radius*radius);
    int height = 3;
    printf("volume of thia cylinder ia %f", pi*radius*radius*height);
    return 0;
}
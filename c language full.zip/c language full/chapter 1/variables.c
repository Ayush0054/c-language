int main(){
    int a= 4;
   // int b =8.5; // not recommended beacuase 8.5 is not a integer
   float b = 8.5;
   char c = 'u';
   int d = 45;
   int e = 45+4;
   printf("the value of b is %f \n",b);
   printf("the value of c is %f ",c);
   printf("SUM OF a AND D IS %d \n", a  + d);
   printf("SUM OF a AND D IS %d \n", e);
   return 0;
}

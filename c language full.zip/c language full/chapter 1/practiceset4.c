#include<stdio.h>
    int main(){
    int principal=100 , rate=4, years=1;
    int simpleinterest = (princi     pal*rate*years)/100;
    printf("thee value of simpleinterest is %d", simpleinterest);
return 0;
}
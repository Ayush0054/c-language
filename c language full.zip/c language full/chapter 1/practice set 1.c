#include <stdio.h>
    int main(){
    int length=5, breadth=4;
    int area = length*breadth;
    printf("the area of this rectangle is %d", area);
return 0;
}